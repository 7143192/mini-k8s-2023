import json


def main(params):
    result = str(int(params["x"]) + 5)
    return {"x":result}
