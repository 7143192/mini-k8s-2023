

def main(params):
    x = int(params["x"])
    content = ""
    if x <= 666:
        content = "the value {} is low!".format(x)
    else:
        content = "the value {} is high!(which should not be in here!)".format(x)
    return {"result":content}
