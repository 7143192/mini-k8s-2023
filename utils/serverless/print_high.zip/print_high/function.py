

def main(params):
    x = int(params["x"])
    content = ""
    if x >= 19980619:
        content = "the value {} is high!".format(x)
    else:
        content = "the value {} is low!(which should not be in here!)".format(x)
    return {"result":content}
